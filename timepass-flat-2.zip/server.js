'use strict';
// Timepass Games server: free points only, no payments, no withdrawals.
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = process.env.PORT || 3000;
const DATA = process.env.DATA_FILE || path.join(__dirname, 'data.json');
const PUB = __dirname;
const STATIC = new Set(['index.html', 'manifest.webmanifest', 'sw.js', 'icon.svg']);
const GAME_IDS = ['slots', 'wheel', 'dice', 'coin', 'hilo', 'bj', 'tp', 'scratch'];

function hashPin(pin, salt) { return crypto.scryptSync(String(pin), salt, 32).toString('hex'); }
function newSecret(pin) { const salt = crypto.randomBytes(12).toString('hex'); return { salt, hash: hashPin(pin, salt) }; }
function checkSecret(pin, s) {
  if (!s) return false;
  const a = Buffer.from(hashPin(pin, s.salt), 'hex'), b = Buffer.from(s.hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

let db;
function load() {
  try { db = JSON.parse(fs.readFileSync(DATA, 'utf8')); } catch (e) { db = null; }
  if (!db) {
    db = { users: {}, tokens: {}, settings: { bonus: 200, wa: '', notice: '', games: {}, admin: newSecret(process.env.ADMIN_PIN || '1234') } };
  }
  GAME_IDS.forEach(id => { if (db.settings.games[id] === undefined) db.settings.games[id] = 1; });
}
let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const tmp = DATA + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db));
    fs.renameSync(tmp, DATA);
  }, 200);
}
load();

const hits = new Map();
function limited(ip) {
  const now = Date.now(), h = (hits.get(ip) || []).filter(t => now - t < 60000);
  h.push(now); hits.set(ip, h);
  return h.length > 20;
}

function publicSettings() {
  const s = db.settings;
  return { bonus: s.bonus, wa: s.wa, notice: s.notice, games: s.games };
}
function publicUser(u) {
  return { name: u.name, points: u.points, played: u.played, won: u.won, lastBonus: u.lastBonus };
}
function leaderboard() {
  return Object.values(db.users).sort((a, b) => b.points - a.points).slice(0, 5).map(u => ({ name: u.name, points: u.points }));
}
function authUser(req) {
  const t = (req.headers.authorization || '').replace('Bearer ', '');
  const key = db.tokens[t];
  return key && db.users[key] ? { key, u: db.users[key] } : null;
}
function isAdmin(req) { return checkSecret(String(req.headers['x-admin-pin'] || ''), db.settings.admin); }

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', c => { n += c.length; if (n > 10000) { reject(new Error('big')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString()) : {}); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}
const num = (v, lo, hi) => Math.max(lo, Math.min(hi, Math.round(Number(v) || 0)));

async function api(req, res, url) {
  const ip = req.socket.remoteAddress || '';
  const body = req.method === 'POST' ? await readBody(req) : {};
  const route = req.method + ' ' + url.pathname;

  if (route === 'GET /api/public') return send(res, 200, { settings: publicSettings(), leaderboard: leaderboard() });

  if (route === 'POST /api/signup' || route === 'POST /api/login') {
    if (limited(ip)) return send(res, 429, { error: 'बहुत ज़्यादा कोशिशें। थोड़ी देर बाद फिर करो।' });
    const name = String(body.name || '').trim().slice(0, 16), pin = String(body.pin || ''), key = name.toLowerCase();
    if (name.length < 2) return send(res, 400, { error: 'नाम कम से कम 2 अक्षर का रखो।' });
    if (!/^\d{4}$/.test(pin)) return send(res, 400, { error: 'PIN ठीक 4 अंकों का होना चाहिए।' });
    if (route.endsWith('signup')) {
      if (db.users[key]) return send(res, 409, { error: 'यह नाम पहले से है। दूसरा नाम चुनो या लॉगिन करो।' });
      db.users[key] = { name, secret: newSecret(pin), points: 1000, played: 0, won: 0, joined: Date.now(), lastBonus: 0 };
    } else if (!db.users[key] || !checkSecret(pin, db.users[key].secret)) {
      return send(res, 401, { error: 'नाम या PIN गलत है।' });
    }
    const token = crypto.randomBytes(24).toString('hex');
    db.tokens[token] = key; save();
    return send(res, 200, { token, user: publicUser(db.users[key]) });
  }

  if (route === 'GET /api/me') {
    const a = authUser(req); if (!a) return send(res, 401, { error: 'login' });
    return send(res, 200, { user: publicUser(a.u) });
  }
  if (route === 'POST /api/me/sync') {
    const a = authUser(req); if (!a) return send(res, 401, { error: 'login' });
    // Points come from the client's games, so cap how far they can move per call.
    a.u.points = num(body.points, 0, a.u.points + 5000);
    a.u.played = num(body.played, a.u.played, a.u.played + 50);
    a.u.won = num(body.won, a.u.won, Math.min(a.u.played, a.u.won + 50));
    save(); return send(res, 200, { user: publicUser(a.u) });
  }
  if (route === 'POST /api/me/bonus') {
    const a = authUser(req); if (!a) return send(res, 401, { error: 'login' });
    if (Date.now() - a.u.lastBonus < 864e5) return send(res, 400, { error: 'बोनस अभी तैयार नहीं है।' });
    a.u.lastBonus = Date.now(); a.u.points += db.settings.bonus; save();
    return send(res, 200, { user: publicUser(a.u) });
  }

  if (url.pathname.startsWith('/api/admin/')) {
    if (limited(ip + 'a')) return send(res, 429, { error: 'बहुत ज़्यादा कोशिशें।' });
    if (!isAdmin(req)) return send(res, 401, { error: 'PIN गलत है।' });
    if (route === 'GET /api/admin/users') {
      return send(res, 200, { users: Object.entries(db.users).map(([k, u]) => Object.assign({ key: k }, publicUser(u))), settings: publicSettings() });
    }
    if (route === 'POST /api/admin/settings') {
      const s = db.settings;
      s.bonus = num(body.bonus, 0, 10000);
      s.wa = String(body.wa || '').replace(/\D/g, '').slice(0, 15);
      s.notice = String(body.notice || '').slice(0, 300);
      GAME_IDS.forEach(id => { if (body.games && id in body.games) s.games[id] = body.games[id] ? 1 : 0; });
      if (body.newPin && String(body.newPin).length >= 4) s.admin = newSecret(String(body.newPin));
      save(); return send(res, 200, { settings: publicSettings() });
    }
    if (route === 'POST /api/admin/bonus-all') {
      const a = num(body.amount, 1, 10000);
      Object.values(db.users).forEach(u => { u.points += a; }); save();
      return send(res, 200, { ok: true });
    }
    if (route === 'POST /api/admin/reset') {
      const u = db.users[String(body.key)]; if (!u) return send(res, 404, { error: 'नहीं मिला' });
      u.points = 1000; save(); return send(res, 200, { ok: true });
    }
    if (route === 'POST /api/admin/delete') {
      const k = String(body.key); delete db.users[k];
      Object.keys(db.tokens).forEach(t => { if (db.tokens[t] === k) delete db.tokens[t]; });
      save(); return send(res, 200, { ok: true });
    }
  }
  send(res, 404, { error: 'not found' });
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png' };
http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    const name = url.pathname.replace(/^\//, '');
    const f = path.join(PUB, STATIC.has(name) ? name : 'index.html');
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
    fs.createReadStream(f).pipe(res);
  } catch (e) { send(res, 400, { error: 'bad request' }); }
}).listen(PORT, () => console.log('Timepass Games on http://localhost:' + PORT));
